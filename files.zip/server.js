// Zero-dependency Node.js server: serves public/ and stores game rooms in memory.
const http=require('http'),fs=require('fs'),path=require('path');
const rooms=new Map(),PORT=process.env.PORT||3000;
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
http.createServer((req,res)=>{
  const u=req.url.split('?')[0];
  if(u.startsWith('/api/rooms/')){
    const code=decodeURIComponent(u.slice(11)).toUpperCase();
    if(req.method==='GET'){
      if(!rooms.has(code)){res.writeHead(404);return res.end();}
      res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(rooms.get(code));
    }
    if(req.method==='PUT'){
      let b='';req.on('data',c=>{b+=c;if(b.length>1e6)req.destroy();});
      req.on('end',()=>{try{JSON.parse(b);rooms.set(code,b);res.writeHead(200);res.end('ok');}catch(e){res.writeHead(400);res.end();}});return;
    }
  }
  const f=path.join(__dirname,'public',u==='/'?'index.html':u);
  if(!f.startsWith(path.join(__dirname,'public'))||!fs.existsSync(f)){res.writeHead(404);return res.end('Not found');}
  res.writeHead(200,{'Content-Type':types[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(res);
}).listen(PORT,()=>console.log('PokerStack running at http://localhost:'+PORT));
