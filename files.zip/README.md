# PokerStack: Stack-Based Texas Hold'em (2 players)

## 1. single-screen/  (no setup)
Open `single-screen/index.html` in a browser. Two players share one screen.
Can be hosted free on GitHub Pages / Netlify (just upload the file).

## 2. two-device/  (needs Node.js, no npm install)
    cd two-device
    node server.js
Open http://localhost:3000 on one device and click "Create room".
On a second device on the same Wi-Fi open http://<your-PC-IP>:3000, enter the code, click Join.
(Testing alone: open two browser tabs. Each tab is a separate player.)
To play over the internet, deploy the two-device folder to Render / Railway
(start command: `node server.js`). Static hosts like GitHub Pages will NOT work for this version.

## Stack usage
- Deck: 52-card stack, deal = pop, peek = top card
- Burn pile: push before flop, turn, river
- Action stack: push every check/call/raise/fold, Undo = pop
Notes: rooms are kept in server memory (lost on restart); hands are hidden on screen only.
